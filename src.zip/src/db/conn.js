const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/effy-api',{
    useNewUrlParser:true,
    useUnifiedTopology:true
}).then(() => {
    console.log("connection success");
}).catch((e) =>{
    console.log("error to connect",e);
})