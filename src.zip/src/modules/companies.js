const mongoose = require('mongoose');
const validator = require('validator');

const companySchema = new mongoose.Schema({
    comp_name : {
        type:String,
        required:true,
        minlength:3
    },
    comp_address : {
        type:String,
        required:true
    },
    location : {
        type:{type:String,required:true},
        coordiantes:[]
    }
});

const Company = new mongoose.model('effy_companies',companySchema);
module.exports = Company;