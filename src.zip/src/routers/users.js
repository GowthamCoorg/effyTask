const express =  require('express');
const router = new express.Router();
const User = require('../modules/users');
// Create a user
router.post('/user', async(req,res) =>{
    try{
        const user = new User(req.body);
        const saveUser = await user.save();
        res.status(201).send(saveUser);

    }catch(e){
        res.status(404).send(e);
    }
});
// List users
router.get('/users', async(req,res) =>{
    try{
        const usersList = await User.find()
        res.status(201).send(usersList);
    }catch(e){
        res.status(404).send(e);
    }
});
// Delete a user
router.get('/userdele/:id', async(req,res) =>{
    try{
        if(!req.params.id){
            res.status(400).send('Invalid request');
        }else{
            const UserDelete = await User.findByIdAndDelete(req.params.id);
            res.status(201).send(UserDelete);
        }
    }catch(e){
        res.status(500).send(e);
    }
});
// Update a user
router.patch('/user/:id', async(req,res) =>{
    try{
        const _id = req.params.id;
        const UserDataUpdate = await User.findByIdAndUpdate(_id, req.body ,{new:true});
        res.status(201).send(UserDataUpdate);
    }catch(e){
        res.status(500).send(e);
    }
});
// Update a user OR Deactivate a user (sets to active=false)
router.get('/user/:id', async(req,res) =>{
    try{
        const _id = req.params.id;
        const UserData = await User.findById(_id);
        if(!UserData){
            res.status(404).send();
        }else{
            res.status(201).send(UserData);
        }
    }catch(e){
        res.status(500).send(e);
    }
});
module.exports = router;