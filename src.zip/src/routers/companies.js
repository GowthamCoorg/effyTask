const express = require('express');
const router = new express.Router();
const Company = require('../modules/companies');
const axios = require('axios');
// Delete a company
router.get('/companydele/:id', async (req, res) => {
    try {
        if (!req.params.id) {
            res.status(400).send('Invalid request');
        } else {
            const CompanyDelete = await Company.findByIdAndDelete(req.params.id);
            res.status(201).send(CompanyDelete);
        }
    } catch (e) {
        res.status(500).send(e);
    }
});
// Get a specific company by ID
router.get('/company/:id', async (req, res) => {
    try {
        const _id = req.params.id;
        const CompanyData = await Company.findById(_id);
        if (!CompanyData) {
            res.status(404).send();
        } else {
            res.status(201).send(CompanyData);
        }
    } catch (e) {
        res.status(500).send(e);
    }
});
// List companies
router.get('/companies', async (req, res) => {
    try {
        const companyList = await Company.find()
        res.status(201).send(companyList);
    } catch (e) {
        res.status(404).send(e);
    }
});
// Create a company
router.post('/company', async(req, res) => {
    try {
        const companyObj = req.body;
        //axios.get('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_week.geojsonp').then( async(resp) => {
            //const coords = resp.data.features[0].geometry.coordinates;
            companyObj.location = {type:"Path",coordiantes:[123.23,965.25]}
            const company = new Company(companyObj);
            const saveComapny = await company.save();
            res.status(201).send(companyObj);
        //});

    } catch (e) {
        res.status(404).send(e);
    }
});
// Update a company
router.patch('/company/:id', async (req, res) => {
    try {
        const _id = req.params.id;
        const CompanyDataUpdate = await Company.findByIdAndUpdate(_id, req.body, { new: true });
        res.status(201).send(CompanyDataUpdate);
    } catch (e) {
        res.status(500).send(e);
    }
});

module.exports = router;